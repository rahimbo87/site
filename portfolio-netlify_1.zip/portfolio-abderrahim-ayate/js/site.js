/* Visionneuse de plans et copie de l'adresse e-mail.
   Sans JavaScript, chaque lien « Agrandir » ouvre simplement l'image en grand. */
(function () {
  "use strict";

  var dialog = document.getElementById("viewer");
  if (dialog && typeof dialog.showModal === "function") {
    var img = dialog.querySelector("img");
    var stage = dialog.querySelector(".viewer-stage");
    var title = dialog.querySelector(".viewer-title");
    var toggle = dialog.querySelector("[data-viewer-toggle]");
    var close = dialog.querySelector("[data-viewer-close]");
    var opener = null;

    var setFull = function (full) {
      stage.classList.toggle("is-full", full);
      toggle.textContent = full ? "Ajuster à l'écran" : "Taille réelle";
      toggle.setAttribute("aria-pressed", full ? "true" : "false");
    };

    document.addEventListener("click", function (event) {
      var link = event.target.closest("a[data-zoom]");
      if (!link || event.metaKey || event.ctrlKey || event.shiftKey) return;
      event.preventDefault();
      opener = link;
      img.src = link.getAttribute("href");
      img.alt = link.getAttribute("data-alt") || "";
      title.textContent = link.getAttribute("data-title") || "";
      setFull(false);
      dialog.showModal();
      close.focus();
    });

    toggle.addEventListener("click", function () {
      setFull(!stage.classList.contains("is-full"));
    });
    close.addEventListener("click", function () { dialog.close(); });
    dialog.addEventListener("click", function (event) {
      if (event.target === stage && !stage.classList.contains("is-full")) dialog.close();
    });
    dialog.addEventListener("close", function () {
      img.removeAttribute("src");
      if (opener) opener.focus();
    });
  }

  var copyButtons = document.querySelectorAll("[data-copy]");
  Array.prototype.forEach.call(copyButtons, function (button) {
    button.hidden = false;
    button.addEventListener("click", function () {
      var value = button.getAttribute("data-copy");
      var done = function () {
        var label = button.textContent;
        button.textContent = "Adresse copiée";
        setTimeout(function () { button.textContent = label; }, 2000);
      };
      var fallback = function () {
        var target = document.getElementById(button.getAttribute("aria-controls"));
        if (!target) return;
        var range = document.createRange();
        range.selectNodeContents(target);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(value).then(done, fallback);
      } else {
        fallback();
      }
    });
  });
})();
